﻿using System;
using System.Drawing;
using System.IO;
using System.Net;
using System.Windows.Forms;
using Guna.UI2.WinForms;

namespace UnicoreLauncher
{
    // Fenêtre pour le téléchargement et gestion des actions liées à "Téléport"
    public partial class TeleportWindow : Form
    {
        private Guna2Button btnDownload;        // Bouton de téléchargement
        private Guna2ProgressBar progressBar;  // Barre de progression pour le téléchargement
        private WebClient webClient;           // Client Web pour le téléchargement
        private string downloadUrl = "https://cdn.discordapp.com/attachments/1266078394517295225/1310263122472337460/Unicore.rar?ex=6745e69f&is=6744951f&hm=df997b52ecf57a1821e97a4d2a0b24910ed52bffe041fceb5dcdc7cd7c126d1a&"; // Remplacez par une URL valide

        public TeleportWindow()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            // Configuration de base de la fenêtre
            this.Text = "Teleport Window";
            this.ClientSize = new Size(400, 300);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.BackColor = Color.FromArgb(28, 28, 40);

            // Création du bouton de téléchargement
            btnDownload = new Guna2Button
            {
                Text = "Download Unicore",
                Size = new Size(300, 40),
                Location = new Point(50, 50),
                BorderRadius = 10,
                FillColor = Color.FromArgb(50, 150, 250),
                ForeColor = Color.White
            };
            btnDownload.Click += BtnDownload_Click; // Attache l'événement Click
            this.Controls.Add(btnDownload);

            // Création de la barre de progression
            progressBar = new Guna2ProgressBar
            {
                Size = new Size(300, 20),
                Location = new Point(50, 120),
                BorderRadius = 10,
                Maximum = 100,
                Minimum = 0,
                Value = 0
            };
            this.Controls.Add(progressBar);
        }

        // Événement lorsque le bouton de téléchargement est cliqué
        private void BtnDownload_Click(object sender, EventArgs e)
        {
            string userDownloadsFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            string downloadPath = Path.Combine(userDownloadsFolder, "Unicore.rar");

            // Configuration du WebClient pour télécharger le fichier
            webClient = new WebClient();
            webClient.DownloadProgressChanged += WebClient_DownloadProgressChanged;
            webClient.DownloadFileCompleted += WebClient_DownloadFileCompleted;

            try
            {
                webClient.DownloadFileAsync(new Uri(downloadUrl), downloadPath); // Démarre le téléchargement
                MessageBox.Show("Téléchargement démarré...", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur : {ex.Message}", "Erreur de téléchargement", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Mise à jour de la barre de progression pendant le téléchargement
        private void WebClient_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            progressBar.Value = e.ProgressPercentage; // Met à jour la barre
        }

        // Gestion de la fin du téléchargement
        private void WebClient_DownloadFileCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                MessageBox.Show($"Échec du téléchargement : {e.Error.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Téléchargement terminé avec succès !", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
