﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using System.Collections.Generic;
using System.IO;
using System.Net;

namespace UnicoreLauncher
{
    public partial class MainWindow : Form
    {
        private readonly List<HardwareComponent> hardwareComponents;

        public MainWindow()
        {
            InitializeComponent();

            hardwareComponents = new List<HardwareComponent>
            {
                new HardwareComponent("MAC Address", true, SpoofingMethods.SpoofMACAddress),
                new HardwareComponent("Serial Numbers", true, SpoofingMethods.SpoofSerialNumbers),
                new HardwareComponent("Monitor Serial", true, SpoofingMethods.SpoofMonitor),
                new HardwareComponent("GPU UUID", true, SpoofingMethods.SpoofGPU),
                new HardwareComponent("Keyboard Serial", true, SpoofingMethods.SpoofKeyboard),
                new HardwareComponent("Disk Serial", true, SpoofingMethods.SpoofDisk),
                new HardwareComponent("Disks/Volumes", true, SpoofingMethods.SpoofDisksAndVolumes), // New entry
                new HardwareComponent("Network Adapters", true, SpoofingMethods.SpoofNetworkAdapters),
                new HardwareComponent("SMBIOS/UEFI", true, SpoofingMethods.SpoofSMBIOSUEFI),
                new HardwareComponent("File/Registry Cleaning", true, SpoofingMethods.PerformFileRegistryCleaning)
            };
        }

        private void InitializeComponent()
        {
            // Main window setup
            this.Text = "Main Dashboard";
            this.ClientSize = new Size(800, 600);
            this.BackColor = Color.FromArgb(28, 28, 40);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            // Sidebar setup
            var sidebar = new Panel
            {
                Size = new Size(200, this.ClientSize.Height),
                Location = new Point(0, 0),
                BackColor = Color.FromArgb(50, 50, 100)
            };
            this.Controls.Add(sidebar);

            // Add buttons for each section
            AddSidebarButton(sidebar, "Spoof Hardware", 50, SpoofHardware);
            AddSidebarButton(sidebar, "Software", 100);
            AddSidebarButton(sidebar, "Extractor", 150);
            AddSidebarButton(sidebar, "Teleport Files (Soon)", 200);

            // Panel for downloading Unicore
            var rightPanel = new Panel
            {
                Size = new Size(200, this.ClientSize.Height),
                Location = new Point(this.ClientSize.Width - 200, 0),
                BackColor = Color.FromArgb(40, 40, 60),
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            };
            this.Controls.Add(rightPanel);

            var btnDownloadUnicore = new Guna2Button
            {
                Text = "Download Unicore",
                Size = new Size(180, 40),
                Location = new Point(10, 50),
                BorderRadius = 10,
                FillColor = Color.FromArgb(70, 70, 200),
                ForeColor = Color.White
            };
            btnDownloadUnicore.Click += (sender, e) => DownloadUnicore();
            rightPanel.Controls.Add(btnDownloadUnicore);
        }

        private void AddSidebarButton(Panel sidebar, string text, int topPosition, Action clickAction = null)
        {
            var button = new Guna2Button
            {
                Text = text,
                Size = new Size(180, 40),
                Location = new Point(10, topPosition),
                BorderRadius = 10,
                FillColor = Color.FromArgb(50, 50, 150),
                ForeColor = Color.White
            };
            if (clickAction != null)
                button.Click += (sender, e) => clickAction();
            sidebar.Controls.Add(button);
        }

        private void SpoofHardware()
        {
            foreach (var component in hardwareComponents)
            {
                if (component.IsEnabled)
                {
                    string result = component.SpoofMethod.Invoke();
                    MessageBox.Show($"{component.Name} spoofed: {result}", "Spoofing", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void DownloadUnicore()
        {
            using (WebClient client = new WebClient())
            {
                try
                {
                    string downloadUrl = "https://example.com/file.rar";
                    string downloadDirectory = @"C:\Downloads";
                    string savePath = Path.Combine(downloadDirectory, "UnicoreLoader.rar");

                    if (!Directory.Exists(downloadDirectory))
                        Directory.CreateDirectory(downloadDirectory);

                    client.DownloadFile(downloadUrl, savePath);
                    MessageBox.Show($"File downloaded successfully to {savePath}!", "Download Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error downloading file: {ex.Message}", "Download Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }

    public class HardwareComponent
    {
        public string Name { get; }
        public bool IsEnabled { get; set; }
        public Func<string> SpoofMethod { get; }

        public HardwareComponent(string name, bool isEnabled, Func<string> spoofMethod)
        {
            Name = name;
            IsEnabled = isEnabled;
            SpoofMethod = spoofMethod;
        }
    }
}
