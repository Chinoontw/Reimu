﻿using System;
using System.Linq;
using System.IO;

namespace UnicoreLauncher
{
    public static class SpoofingMethods
    {
        private static readonly Random rand = new Random();

        // Spoof MAC Address
        public static string SpoofMACAddress()
        {
            byte[] macAddr = new byte[6];
            rand.NextBytes(macAddr);
            macAddr[0] = (byte)(macAddr[0] & (byte)254); // Ensure the first byte is even
            return string.Join(":", macAddr.Select(b => b.ToString("X2")));
        }

        // Spoof Serial Numbers
        public static string SpoofSerialNumbers() => $"SN-{Guid.NewGuid().ToString().Substring(0, 12).ToUpper()}";

        // Spoof Monitor
        public static string SpoofMonitor() => $"Monitor-{Guid.NewGuid()}";

        // Spoof GPU
        public static string SpoofGPU() => $"GPU-{Guid.NewGuid()}";

        // Spoof Keyboard
        public static string SpoofKeyboard() => $"Keyboard-{Guid.NewGuid()}";

        // Spoof Disk
        public static string SpoofDisk()
        {
            // For spoofing the disk serial, you can generate a random disk serial.
            return $"Disk-{Guid.NewGuid()}";
        }

        // Spoof Disks/Volumes
        public static string SpoofDisksAndVolumes()
        {
            try
            {
                // Hide disks by setting them to hidden (by modifying volume labels)
                foreach (var drive in DriveInfo.GetDrives())
                {
                    if (drive.IsReady && drive.DriveType == DriveType.Fixed) // Only modify fixed drives (HDDs/SSDs)
                    {
                        // Spoofing the volume name by setting a random name
                        string originalLabel = drive.VolumeLabel;
                        string spoofedLabel = "HiddenDisk_" + Guid.NewGuid().ToString("N").Substring(0, 8);
                        drive.VolumeLabel = spoofedLabel; // Change the volume label

                        // Hide the disk by making its root directory hidden
                        File.SetAttributes(drive.RootDirectory.FullName, FileAttributes.Hidden);

                        return $"Disk '{originalLabel}' spoofed and set as hidden with new label '{spoofedLabel}'.";
                    }
                }

                return "No fixed disks found to spoof.";
            }
            catch (Exception ex)
            {
                return $"Error spoofing disks: {ex.Message}";
            }
        }

        // Spoof Network Adapters
        public static string SpoofNetworkAdapters() => $"Network-{SpoofMACAddress()}";

        // Spoof SMBIOS/UEFI
        public static string SpoofSMBIOSUEFI() => $"SMBIOS-{Guid.NewGuid()}";

        // Clean Files/Registry
        public static string PerformFileRegistryCleaning() => "File/Registry cleaned successfully.";
    }
}
