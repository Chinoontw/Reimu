﻿using System;
using System.Drawing;
using System.IO;
using System.Net;
using System.Windows.Forms;
using Guna.UI2.WinForms;

namespace UnicoreLauncher
{
    public partial class LoginForm : Form
    {
        // Déclaration des champs d'instance pour les champs de texte
        private Guna2TextBox txtUsername;
        private Guna2TextBox txtPassword;

        private readonly string versionUrl = "https://raw.githubusercontent.com/Chinoontw/Loader/main/version.txt";
        private readonly string changelogUrl = "https://raw.githubusercontent.com/Chinoontw/Loader/main/changelog.txt";
        private readonly string releaseUrl = "https://github.com/Chinoontw/Loader/releases/latest"; // Lien vers la dernière release sur GitHub

        public LoginForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            // Masquer l'icône de la fenêtre
            this.Icon = null; // Ajoutez cette ligne pour masquer l'icône

            // Propriétés principales de la fenêtre
            this.Text = "Login";
            this.ClientSize = new Size(400, 500);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.BackColor = Color.FromArgb(28, 28, 40);

            // Champ Username
            txtUsername = new Guna2TextBox
            {
                PlaceholderText = "Username",
                Size = new Size(300, 40),
                Location = new Point(50, 150),
                BorderRadius = 10
            };
            this.Controls.Add(txtUsername);

            // Champ Password
            txtPassword = new Guna2TextBox
            {
                PlaceholderText = "Password",
                UseSystemPasswordChar = true,
                Size = new Size(300, 40),
                Location = new Point(50, 200),
                BorderRadius = 10
            };
            this.Controls.Add(txtPassword);

            // Bouton Login
            var btnLogin = new Guna2Button
            {
                Text = "Login",
                Size = new Size(300, 40),
                Location = new Point(50, 260),
                BorderRadius = 10
            };
            btnLogin.Click += (sender, e) => LocalLogin(txtUsername.Text, txtPassword.Text);
            this.Controls.Add(btnLogin);

            // Bouton Exit
            var btnExit = new Guna2Button
            {
                Text = "Exit",
                Size = new Size(300, 40),
                Location = new Point(50, 320),
                BorderRadius = 10,
                FillColor = Color.FromArgb(200, 50, 50)
            };
            btnExit.Click += (sender, e) => this.Close();
            this.Controls.Add(btnExit);

            // Bouton Check Updates
            var btnCheckUpdates = new Guna2Button
            {
                Text = "Check for Updates",
                Size = new Size(300, 40),
                Location = new Point(50, 380),
                BorderRadius = 10
            };
            btnCheckUpdates.Click += (sender, e) => CheckForUpdates();
            this.Controls.Add(btnCheckUpdates);
        }

        private void CheckForUpdates()
        {
            try
            {
                using (WebClient client = new WebClient())
                {
                    string latestVersion = client.DownloadString(versionUrl).Trim();
                    string currentVersion = Application.ProductVersion;

                    if (latestVersion != currentVersion)
                    {
                        DialogResult dialogResult = MessageBox.Show($"A new version {latestVersion} is available!\n\nWould you like to view the changelog?", "New Version Available", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                        if (dialogResult == DialogResult.Yes)
                        {
                            string changelog = client.DownloadString(changelogUrl);
                            MessageBox.Show(changelog, "Changelog", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }

                        System.Diagnostics.Process.Start(releaseUrl);
                    }
                    else
                    {
                        MessageBox.Show("You are using the latest version!", "No Updates", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error checking for updates: {ex.Message}", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LocalLogin(string username, string password)
        {
            if (username == "admin" && password == "admin")
            {
                LogConnection("Admin login attempt successful");
                OpenWindow(new MainWindow());
            }
            else if (username == "spoofer" && password == "strinova")
            {
                LogConnection("Spoofer login attempt successful");
                OpenWindow(new MainWindow());
            }
            else if (username == "teleport" && password == "teleport")
            {
                LogConnection("Teleport login attempt successful");
                OpenWindow(new TeleportWindow());
            }
            else
            {
                LogConnection("Invalid login attempt");
                MessageBox.Show("Invalid Credentials", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void OpenWindow(Form newWindow)
        {
            newWindow.Show();
            this.Hide();
        }

        private void LogConnection(string message)
        {
            string logFilePath = "loginLogs.txt";
            string logMessage = $"{DateTime.Now}: {message}";

            try
            {
                File.AppendAllText(logFilePath, logMessage + Environment.NewLine);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to log message: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
